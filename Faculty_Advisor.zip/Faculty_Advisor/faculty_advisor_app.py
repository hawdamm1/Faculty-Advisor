"""
=============================================================================
 FACULTY ADVISOR - Kurdistan College Recommendation System
=============================================================================
This is a Tkinter desktop application that predicts which university
faculty (college) best suits a student, based on their scores in 7
subjects: Kurdish, English, Arabic, Math, Physics, Chemistry, Biology.

HOW IT WORKS (short version):
1. We already trained a RandomForestClassifier on a cleaned dataset of
   student scores + the faculty each student ended up in
   (see Cleaning_Training_Code/data_cleaning.py and train model.py).
2. The trained model was saved to disk as "rf_faculty_model.pkl", and the
   LabelEncoder (which turns faculty names into numbers and back) was
   saved as "label_encoder.pkl".
3. This GUI just LOADS those two files, takes the 7 scores the user
   types in, feeds them to the model, and displays the predicted faculty
   plus a confidence breakdown for every faculty.

No internet connection or retraining is needed to run this app - it only
needs the two .pkl files that live in the "Models" folder next to this
script.
=============================================================================
"""

# ---------------------------------------------------------------------------
# STEP 1: IMPORTS
# ---------------------------------------------------------------------------
# tkinter / ttk -> everything needed to build the desktop window and widgets
# messagebox   -> pop-up windows for errors/info
# os / sys     -> used to build a file path that works no matter where the
#                 script is run from
# pickle       -> used to load the .pkl model files we trained earlier
# numpy        -> the model expects a 2D array of numbers as input
# -----------------------------------------------------------------------
import os
import sys
import pickle
import tkinter as tk
from tkinter import ttk, messagebox

import numpy as np


# ---------------------------------------------------------------------------
# STEP 2: APP CONFIGURATION (COLORS, FONTS, FILE PATHS)
# ---------------------------------------------------------------------------
# Keeping all the "design" values in one place makes it easy to re-theme the
# whole app later by only changing this section.
# ---------------------------------------------------------------------------

# Folder where THIS script lives (works even if the user double-clicks it
# from a different working directory).
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "Models", "rf_faculty_model.pkl")
ENCODER_PATH = os.path.join(BASE_DIR, "Models", "label_encoder.pkl")

# The exact column order the model was trained on. This MUST match
# train model.py's `feature_cols`, or predictions will be wrong.
FEATURE_COLUMNS = [
    "Kurdish", "English", "Arabic", "Math",
    "Physics", "Chemistry", "Biology", "Average_Score",
]

# The 7 subjects the user actually types in (Average_Score is calculated
# automatically from these, not typed by hand).
SUBJECTS = ["Kurdish", "English", "Arabic", "Math", "Physics", "Chemistry", "Biology"]

# A colour palette for a clean, modern "flat UI" look.
COLORS = {
    "bg":           "#0f172a",   # app background (dark navy)
    "panel":        "#1e293b",   # card / panel background
    "panel_light":  "#273449",   # slightly lighter panel (input fields)
    "accent":       "#38bdf8",   # sky blue accent (buttons, highlights)
    "accent_dark":  "#0284c7",   # pressed / hover state
    "text":         "#e2e8f0",   # main text colour (near white)
    "text_dim":     "#94a3b8",   # secondary / muted text
    "success":      "#4ade80",   # green for the winning faculty
    "bar_bg":       "#334155",   # background track of the probability bars
}

FONT_TITLE = ("Segoe UI", 20, "bold")
FONT_SUBTITLE = ("Segoe UI", 10)
FONT_LABEL = ("Segoe UI", 10, "bold")
FONT_ENTRY = ("Segoe UI", 11)
FONT_RESULT = ("Segoe UI", 16, "bold")
FONT_SMALL = ("Segoe UI", 9)


# ---------------------------------------------------------------------------
# STEP 3: LOAD THE TRAINED MODEL + LABEL ENCODER
# ---------------------------------------------------------------------------
def load_model_and_encoder():
    """
    Loads the pickled RandomForest model and the LabelEncoder from disk.

    Returns:
        (model, label_encoder) tuple.

    If the files are missing, we show a friendly error box and close the
    app instead of crashing with a raw Python traceback.
    """
    try:
        with open(MODEL_PATH, "rb") as f:
            model = pickle.load(f)
        with open(ENCODER_PATH, "rb") as f:
            label_encoder = pickle.load(f)
        return model, label_encoder
    except FileNotFoundError as e:
        # This runs BEFORE the main window exists, so we use a temporary
        # hidden root window just so messagebox has a parent to attach to.
        temp_root = tk.Tk()
        temp_root.withdraw()
        messagebox.showerror(
            "Missing Model Files",
            "Could not find the trained model files.\n\n"
            f"Expected:\n  {MODEL_PATH}\n  {ENCODER_PATH}\n\n"
            "Make sure the 'Models' folder (with rf_faculty_model.pkl and "
            "label_encoder.pkl) sits in the same directory as this script.\n\n"
            f"Details: {e}",
        )
        temp_root.destroy()
        sys.exit(1)


# ---------------------------------------------------------------------------
# STEP 4: A SMALL REUSABLE WIDGET - A "SCORE INPUT ROW"
# ---------------------------------------------------------------------------
# Each subject gets: a label + a slider (0-100) + a number entry box, both
# kept in sync with each other. Building this once as a class keeps the
# main app code short and avoids repeating the same 20 lines 7 times.
# ---------------------------------------------------------------------------
class ScoreInput(ttk.Frame):
    """A labelled slider + numeric entry pair for one subject's score (0-100)."""

    def __init__(self, parent, subject_name, default_value=75, **kwargs):
        super().__init__(parent, style="Panel.TFrame", **kwargs)
        self.subject_name = subject_name

        # tk.DoubleVar links the slider and the entry box together - when
        # one changes, the other updates automatically.
        self.value_var = tk.DoubleVar(value=default_value)

        # --- Subject name label (left side) ---
        name_label = ttk.Label(
            self, text=subject_name, style="FieldName.TLabel", width=11, anchor="w"
        )
        name_label.grid(row=0, column=0, sticky="w", padx=(0, 8))

        # --- Slider (middle) ---
        self.slider = ttk.Scale(
            self,
            from_=0,
            to=100,
            orient="horizontal",
            variable=self.value_var,
            command=self._on_slider_move,
            style="Accent.Horizontal.TScale",
        )
        self.slider.grid(row=0, column=1, sticky="ew", padx=8)

        # --- Numeric entry box (right side) shows the exact score ---
        self.entry_text = tk.StringVar(value=str(default_value))
        self.entry = tk.Entry(
            self,
            textvariable=self.entry_text,
            width=5,
            font=FONT_ENTRY,
            justify="center",
            bg=COLORS["panel_light"],
            fg=COLORS["text"],
            insertbackground=COLORS["text"],  # cursor colour
            relief="flat",
            highlightthickness=1,
            highlightbackground=COLORS["bar_bg"],
            highlightcolor=COLORS["accent"],
        )
        self.entry.grid(row=0, column=2, padx=(8, 0))
        # Pressing Enter (or clicking away) in the box updates the slider.
        self.entry.bind("<Return>", self._on_entry_change)
        self.entry.bind("<FocusOut>", self._on_entry_change)

        # Let the slider column stretch when the window is resized.
        self.columnconfigure(1, weight=1)

    def _on_slider_move(self, _event=None):
        """Slider moved -> update the number shown in the entry box."""
        self.entry_text.set(str(round(self.value_var.get())))

    def _on_entry_change(self, _event=None):
        """User typed a number -> validate it and move the slider to match."""
        raw = self.entry_text.get().strip()
        try:
            value = float(raw)
        except ValueError:
            value = self.value_var.get()  # invalid text -> ignore, keep old value

        # Clamp the value into the valid 0-100 score range.
        value = max(0, min(100, value))
        self.value_var.set(value)
        self.entry_text.set(str(round(value)))

    def get_value(self):
        """Returns the current score as a float, used when building the prediction."""
        return float(self.value_var.get())


# ---------------------------------------------------------------------------
# STEP 5: A REUSABLE WIDGET - ONE ROW OF THE "RESULTS" PROBABILITY CHART
# ---------------------------------------------------------------------------
class ProbabilityBar(ttk.Frame):
    """One horizontal bar showing the model's confidence for a single faculty."""

    def __init__(self, parent, faculty_name, **kwargs):
        super().__init__(parent, style="Panel.TFrame", **kwargs)

        # Faculty name (left, fixed width so all bars line up neatly)
        self.name_label = ttk.Label(
            self, text=faculty_name, style="BarName.TLabel", width=26, anchor="w"
        )
        self.name_label.grid(row=0, column=0, sticky="w")

        # A Canvas is used to draw the bar itself, because ttk has no
        # built-in "progress bar with custom color per row" widget that
        # looks good without extra styling headaches.
        self.canvas = tk.Canvas(
            self, height=18, width=260, bg=COLORS["bar_bg"],
            highlightthickness=0,
        )
        self.canvas.grid(row=0, column=1, sticky="ew", padx=8)
        self.bar_rect = self.canvas.create_rectangle(
            0, 0, 0, 18, fill=COLORS["accent"], width=0
        )

        # Percentage text (right)
        self.pct_label = ttk.Label(self, text="0%", style="BarPct.TLabel", width=5)
        self.pct_label.grid(row=0, column=2, sticky="e")

        self.columnconfigure(1, weight=1)

    def set_value(self, probability, is_top_choice=False):
        """
        Updates the bar's fill width and % text.

        probability   -> a float between 0 and 1
        is_top_choice -> True for the model's #1 predicted faculty, used to
                          colour that bar green instead of blue.
        """
        pct = probability * 100
        self.pct_label.configure(text=f"{pct:.1f}%")

        color = COLORS["success"] if is_top_choice else COLORS["accent"]
        self.canvas.itemconfig(self.bar_rect, fill=color)

        # The canvas width isn't known until it's actually drawn on screen,
        # so we ask Tkinter to update pending geometry first.
        self.canvas.update_idletasks()
        full_width = self.canvas.winfo_width() or 260
        bar_width = int(full_width * probability)
        self.canvas.coords(self.bar_rect, 0, 0, bar_width, 18)

        # Bold the faculty name if it's the winning prediction.
        font = ("Segoe UI", 9, "bold") if is_top_choice else ("Segoe UI", 9)
        self.name_label.configure(font=font)


# ---------------------------------------------------------------------------
# STEP 6: THE MAIN APPLICATION WINDOW
# ---------------------------------------------------------------------------
class FacultyAdvisorApp(tk.Tk):
    """The main Tkinter window that ties every widget above together."""

    def __init__(self, model, label_encoder):
        super().__init__()
        self.model = model
        self.label_encoder = label_encoder

        # --- Window basics ---
        self.title("Faculty Advisor - AI Recommendation System")
        self.geometry("760x760")
        self.minsize(700, 700)
        self.configure(bg=COLORS["bg"])

        self._setup_styles()
        self._build_layout()

    # -----------------------------------------------------------------
    # STYLING - ttk widgets are themed through a ttk.Style() object,
    # since plain ttk widgets ignore bg=/fg= like classic tk widgets do.
    # -----------------------------------------------------------------
    def _setup_styles(self):
        style = ttk.Style(self)
        # "clam" is the most re-themeable built-in ttk theme.
        style.theme_use("clam")

        style.configure("App.TFrame", background=COLORS["bg"])
        style.configure("Panel.TFrame", background=COLORS["panel"])

        style.configure(
            "Title.TLabel", background=COLORS["bg"], foreground=COLORS["text"],
            font=FONT_TITLE,
        )
        style.configure(
            "Subtitle.TLabel", background=COLORS["bg"], foreground=COLORS["text_dim"],
            font=FONT_SUBTITLE,
        )
        style.configure(
            "SectionTitle.TLabel", background=COLORS["panel"], foreground=COLORS["accent"],
            font=FONT_LABEL,
        )
        style.configure(
            "FieldName.TLabel", background=COLORS["panel"], foreground=COLORS["text"],
            font=FONT_LABEL,
        )
        style.configure(
            "BarName.TLabel", background=COLORS["panel"], foreground=COLORS["text"],
            font=FONT_SMALL,
        )
        style.configure(
            "BarPct.TLabel", background=COLORS["panel"], foreground=COLORS["text_dim"],
            font=FONT_SMALL,
        )
        style.configure(
            "ResultTitle.TLabel", background=COLORS["panel"], foreground=COLORS["text_dim"],
            font=FONT_SUBTITLE,
        )
        style.configure(
            "ResultValue.TLabel", background=COLORS["panel"], foreground=COLORS["success"],
            font=FONT_RESULT,
        )
        style.configure(
            "Footer.TLabel", background=COLORS["bg"], foreground=COLORS["text_dim"],
            font=FONT_SMALL,
        )

        # Slider (ttk.Scale) styling
        style.configure(
            "Accent.Horizontal.TScale", background=COLORS["panel"],
            troughcolor=COLORS["bar_bg"], sliderthickness=16,
        )

        # Main "Predict" button
        style.configure(
            "Accent.TButton", background=COLORS["accent"], foreground="#04202e",
            font=("Segoe UI", 12, "bold"), padding=10, borderwidth=0,
        )
        style.map(
            "Accent.TButton",
            background=[("active", COLORS["accent_dark"]), ("pressed", COLORS["accent_dark"])],
        )

        # Secondary "Reset" button
        style.configure(
            "Ghost.TButton", background=COLORS["panel_light"], foreground=COLORS["text"],
            font=("Segoe UI", 10), padding=8, borderwidth=0,
        )
        style.map("Ghost.TButton", background=[("active", COLORS["bar_bg"])])

    # -----------------------------------------------------------------
    # LAYOUT - builds every section of the window, top to bottom.
    # -----------------------------------------------------------------
    def _build_layout(self):
        outer = ttk.Frame(self, style="App.TFrame", padding=20)
        outer.pack(fill="both", expand=True)

        # ---- Header ----
        ttk.Label(outer, text="🎓 Faculty Advisor", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            outer,
            text="Enter a student's scores to get an AI-powered faculty recommendation.",
            style="Subtitle.TLabel",
        ).pack(anchor="w", pady=(0, 16))

        # ---- Input panel (card) ----
        input_panel = ttk.Frame(outer, style="Panel.TFrame", padding=18)
        input_panel.pack(fill="x")

        ttk.Label(
            input_panel, text="STUDENT SCORES (0 - 100)", style="SectionTitle.TLabel"
        ).pack(anchor="w", pady=(0, 10))

        # Create one ScoreInput row per subject and keep references to them
        # in a dict so we can read their values later when predicting.
        self.score_inputs = {}
        for subject in SUBJECTS:
            row = ScoreInput(input_panel, subject, default_value=75)
            row.pack(fill="x", pady=4)
            self.score_inputs[subject] = row

        # ---- Average score (auto-calculated, read-only display) ----
        avg_row = ttk.Frame(input_panel, style="Panel.TFrame")
        avg_row.pack(fill="x", pady=(10, 0))
        ttk.Label(avg_row, text="Average Score:", style="FieldName.TLabel").pack(side="left")
        self.avg_value_label = ttk.Label(
            avg_row, text="75.0", style="ResultValue.TLabel", font=("Segoe UI", 12, "bold")
        )
        self.avg_value_label.pack(side="left", padx=(8, 0))
        # Recalculate the live average whenever any slider moves.
        for row in self.score_inputs.values():
            row.value_var.trace_add("write", lambda *args: self._update_average())

        # ---- Buttons ----
        button_row = ttk.Frame(outer, style="App.TFrame")
        button_row.pack(fill="x", pady=16)
        ttk.Button(
            button_row, text="🔮  Predict Faculty", style="Accent.TButton",
            command=self.predict,
        ).pack(side="left")
        ttk.Button(
            button_row, text="Reset", style="Ghost.TButton", command=self.reset_fields,
        ).pack(side="left", padx=(10, 0))

        # ---- Results panel (card) ----
        result_panel = ttk.Frame(outer, style="Panel.TFrame", padding=18)
        result_panel.pack(fill="both", expand=True)

        ttk.Label(
            result_panel, text="RECOMMENDATION", style="SectionTitle.TLabel"
        ).pack(anchor="w")

        self.result_title_label = ttk.Label(
            result_panel, text="Fill in the scores above and click Predict.",
            style="ResultTitle.TLabel", wraplength=680,
        )
        self.result_title_label.pack(anchor="w", pady=(4, 12))

        # This frame holds the 7 ProbabilityBar rows, one per faculty. It's
        # rebuilt (cleared + repopulated) each time predict() runs so the
        # bars can be sorted by confidence, winner first.
        self.bars_frame = ttk.Frame(result_panel, style="Panel.TFrame")
        self.bars_frame.pack(fill="both", expand=True)
        self.probability_bars = {}

        # Pre-create one bar per known faculty, in the encoder's order, so
        # the layout looks populated even before the first prediction.
        for faculty in self.label_encoder.classes_:
            bar = ProbabilityBar(self.bars_frame, faculty)
            bar.pack(fill="x", pady=3)
            self.probability_bars[faculty] = bar

        # ---- Footer ----
        ttk.Label(
            outer,
            text="Model: RandomForestClassifier  •  Trained on the Kurdistan College "
                 "Recommendation Dataset",
            style="Footer.TLabel",
        ).pack(anchor="w", pady=(12, 0))

    # -----------------------------------------------------------------
    # LOGIC
    # -----------------------------------------------------------------
    def _update_average(self):
        """Recomputes and displays the live average of the 7 subject scores."""
        values = [row.get_value() for row in self.score_inputs.values()]
        avg = sum(values) / len(values)
        self.avg_value_label.configure(text=f"{avg:.1f}")

    def predict(self):
        """
        Reads the 7 subject scores, builds the exact feature vector the
        model expects, runs the prediction, and updates the UI with the
        winning faculty plus a confidence bar for every faculty.
        """
        try:
            # Build the feature dictionary in the SAME column order used
            # during training (FEATURE_COLUMNS).
            scores = {s: self.score_inputs[s].get_value() for s in SUBJECTS}
            average_score = sum(scores.values()) / len(scores)

            feature_row = [scores[col] if col in scores else average_score
                            for col in FEATURE_COLUMNS]
            X = np.array([feature_row])  # model expects a 2D array: (1 sample, 8 features)

            # predict_proba gives a confidence score for EVERY class, which
            # is far more informative for the user than a single label.
            probabilities = self.model.predict_proba(X)[0]
            predicted_index = int(np.argmax(probabilities))
            predicted_faculty = self.label_encoder.classes_[predicted_index]
            confidence = probabilities[predicted_index] * 100

            # --- Update the headline result text ---
            self.result_title_label.configure(
                text=f"✅  Recommended Faculty:  {predicted_faculty}   "
                     f"({confidence:.1f}% confidence)",
                style="ResultValue.TLabel",
            )

            # --- Update every probability bar, sorted highest-first ---
            # Clear old bars and redraw in sorted order so the winner is
            # always visually on top.
            for bar in self.probability_bars.values():
                bar.destroy()
            self.probability_bars.clear()

            faculty_and_prob = list(zip(self.label_encoder.classes_, probabilities))
            faculty_and_prob.sort(key=lambda pair: pair[1], reverse=True)

            for faculty, prob in faculty_and_prob:
                bar = ProbabilityBar(self.bars_frame, faculty)
                bar.pack(fill="x", pady=3)
                bar.set_value(prob, is_top_choice=(faculty == predicted_faculty))
                self.probability_bars[faculty] = bar

        except Exception as e:
            messagebox.showerror("Prediction Error", f"Something went wrong:\n\n{e}")

    def reset_fields(self):
        """Puts every slider back to the default (75) and clears the result text."""
        for row in self.score_inputs.values():
            row.value_var.set(75)
            row.entry_text.set("75")
        self.result_title_label.configure(
            text="Fill in the scores above and click Predict.",
            style="ResultTitle.TLabel",
        )
        for bar in self.probability_bars.values():
            bar.set_value(0.0, is_top_choice=False)


# ---------------------------------------------------------------------------
# STEP 7: ENTRY POINT
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    trained_model, faculty_label_encoder = load_model_and_encoder()
    app = FacultyAdvisorApp(trained_model, faculty_label_encoder)
    app.mainloop()
