# 🎓 Faculty Advisor — AI College Recommendation System

Faculty Advisor is a machine learning project that recommends the most
suitable university **faculty (college)** for a Kurdistan Region high‑school
student, based on their scores in 7 core subjects. It includes the full
pipeline — data cleaning, model training, and a desktop **Tkinter GUI** for
making live predictions.

> Given a student's scores in Kurdish, English, Arabic, Math, Physics,
> Chemistry and Biology, the app predicts which of the 7 official faculties
> best fits them, along with a confidence score for every faculty.

---

## ✨ Features

- **Clean, modern desktop GUI** built with Tkinter — sliders + numeric
  entry for each subject, a live average score, and a one-click prediction.
- **Full confidence breakdown** — not just the top faculty, but a ranked
  probability bar for all 7 faculties.
- **End-to-end pipeline included** — the raw dataset, the cleaning script,
  and the training script are all in the repo, not just the final model.
- **No retraining required to run the app** — the trained model is saved
  and shipped as a `.pkl` file, so the GUI starts instantly.

---

## 🗂️ Project Structure

```
Faculty_Advisor/
├── faculty_advisor_app.py        # The Tkinter GUI application (run this)
├── requirements.txt               # Python dependencies
├── Cleaning_Training_Code/
│   ├── data_cleaning.py           # Cleans the raw dataset
│   └── train model.py             # Trains & evaluates the RandomForest model
├── Dataset/
│   ├── dirty_kurdistan_college_recommendation_dataset.csv   # Raw data
│   └── cleaned_kurdistan_college_recommendation_dataset.csv # Cleaned data
└── Models/
    ├── rf_faculty_model.pkl       # Trained RandomForestClassifier
    └── label_encoder.pkl          # LabelEncoder for the faculty names
```

---

## 🧠 How It Works

1. **Data Cleaning** (`Cleaning_Training_Code/data_cleaning.py`)
   - Loads the raw survey dataset.
   - Drops duplicate rows and irrelevant columns (`Student_ID`,
     `Favorite_Color`, `Random_Score_Index`).
   - Treats out-of-range subject scores (below 0 or above 100) as missing,
     then fills them back in with **KNN imputation** (`k = 5`).
   - Recalculates each student's `Average_Score`.
   - Standardizes the `Recommended_Faculty` text and fuzzy-matches it
     against the 7 official faculty names using `difflib`, fixing typos
     and inconsistent naming.

2. **Model Training** (`Cleaning_Training_Code/train model.py`)
   - Features: the 7 subject scores + `Average_Score` (8 features total).
   - Target: `Recommended_Faculty`, encoded to integers with
     `LabelEncoder`.
   - Splits the data 80/20 (stratified) and trains a
     `RandomForestClassifier(n_estimators=100)`.
   - Saves the trained model and the label encoder to `Models/` as
     `.pkl` files.

3. **The GUI** (`faculty_advisor_app.py`)
   - Loads `rf_faculty_model.pkl` and `label_encoder.pkl` at startup.
   - Lets the user enter (or drag a slider for) each subject score.
   - Builds the same 8-feature vector the model was trained on, calls
     `model.predict_proba()`, and displays the winning faculty plus a
     confidence bar for every faculty.

---

## 🏫 The 7 Official Faculties

- Business, Economics & Finance
- Engineering & IT
- General Technical Diploma
- Humanities & Law
- Medical & Health Sciences
- Physical Education
- Pure & Applied Sciences

---

## 🚀 Getting Started

### 1. Clone the repository
```bash
git clone https://github.com/<your-username>/faculty-advisor.git
cd faculty-advisor
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```
> Tkinter ships with most standard Python installations. On some Linux
> distributions you may need to install it separately, e.g.
> `sudo apt install python3-tk`.

### 3. Run the app
```bash
python faculty_advisor_app.py
```

That's it — the pre-trained model loads automatically from `Models/`, so
no training step is required to use the GUI.

### (Optional) Retrain the model yourself
```bash
cd "Cleaning_Training_Code"
python data_cleaning.py      # produces a cleaned CSV (edit the paths first)
python "train model.py"      # trains and evaluates the model
```
> Note: the cleaning and training scripts currently use absolute Windows
> file paths (`E:/visual studio 1st file/...`). Update those paths to match
> your own machine before rerunning them.

---

## 📊 Model Performance

The `RandomForestClassifier` was evaluated on a held-out 20% test split
(stratified by faculty):

| Metric | Score |
|---|---|
| **Overall Accuracy** | ~71% |
| Best-performing class | Medical & Health Sciences (F1 ≈ 0.95) |
| Weakest class | Physical Education (only 46 samples in the whole dataset) |

Full breakdown is in [`REPORT.md`](REPORT.md) / the project report.

---

## 🛠️ Tech Stack

- **Python 3**
- **Tkinter / ttk** — desktop GUI
- **scikit-learn** — RandomForestClassifier, LabelEncoder, KNNImputer
- **pandas / numpy** — data handling
- **difflib** — fuzzy string matching for faculty name cleanup

---

## 📌 Notes & Limitations

- The dataset is imbalanced: `Physical Education` has only 46 rows out of
  14,625, which limits how well the model can learn that class.
- The cleaning/training scripts reference local absolute file paths and
  need to be edited before being rerun on a new machine.
- This project is for educational purposes and should be treated as a
  decision-support suggestion, not a substitute for professional academic
  counseling.

---

## 📄 License

This project is released for educational purposes. Feel free to fork,
learn from, and build on it.
