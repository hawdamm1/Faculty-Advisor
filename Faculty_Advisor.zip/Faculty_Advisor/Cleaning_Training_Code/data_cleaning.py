import numpy as np
import pandas as pd
import difflib
from sklearn.impute import KNNImputer

# Load the raw dataset
df = pd.read_csv('E:/visual studio 1st file/Faculty_Advisor/Dataset/dirty_kurdistan_college_recommendation_dataset.csv')

# Inspect properties
print("Initial Dataset Shape:", df.shape)
print("\nMissing Values Count:\n", df.isnull().sum())
print("\nTotal Duplicate Rows:", df.duplicated().sum())

# Remove duplicate rows
df = df.drop_duplicates()

# Remove unnecessary columns
df = df.drop(columns=['Student_ID', 'Favorite_Color', 'Random_Score_Index'], errors='ignore')

# Convert numeric subject outliers (<0 or >100) to NaN
subjects = ['Kurdish', 'English', 'Arabic', 'Math', 'Physics', 'Chemistry', 'Biology']
for col in subjects:
    df.loc[(df[col] < 0) | (df[col] > 100), col] = np.nan

# Handling missing values using KNN imputation
imputer = KNNImputer(n_neighbors=5)
df[subjects] = imputer.fit_transform(df[subjects])

# Recalculate Average_Score
df['Average_Score'] = df[subjects].mean(axis=1)

# Clean Categorical Data (Recommended_Faculty)
df = df.dropna(subset=['Recommended_Faculty'])
df['Recommended_Faculty'] = df['Recommended_Faculty'].str.strip().str.title()

# Official list of the 7 main faculties
official_faculties = [
    'Business, Economics & Finance',
    'Engineering & IT',
    'General Technical Diploma',
    'Humanities & Law',
    'Medical & Health Sciences',
    'Physical Education',
    'Pure & Applied Sciences'
]

# fixing the faculty names to match the official list using difflib
def fix_to_official_faculty(faculty_name):
    matches = difflib.get_close_matches(faculty_name, official_faculties, n=1, cutoff=0.4)
    return matches[0] if matches else faculty_name

df['Recommended_Faculty'] = df['Recommended_Faculty'].apply(fix_to_official_faculty)

# Final Cleaning Inspection
print("\n=== Cleaning Complete ===")
print("Remaining Clean Rows:", len(df))
print("Missing Values Count:\n", df.isnull().sum())
print("Clean Faculties Count:", df['Recommended_Faculty'].nunique())

# Save clean dataset
#df.to_csv('E:/visual studio 1st file/Faculty_Advisor/Dataset/cleaned_kurdistan_college_recommendation_dataset.csv', index=False)