import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

# Load Cleaned Dataset v2
df = pd.read_csv('E:/visual studio 1st file/Faculty_Advisor\\Dataset\\cleaned_kurdistan_college_recommendation_dataset.csv')

# Separate Features (X) and Target (y)
feature_cols = ['Kurdish', 'English', 'Arabic', 'Math', 'Physics', 'Chemistry', 'Biology', 'Average_Score']
X = df[feature_cols]
y_text = df['Recommended_Faculty']

# Label Encoding
label_encoder = LabelEncoder()
y = label_encoder.fit_transform(y_text)

# Train-Test Split (80% Train, 20% Test)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Initialize and Train Model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Evaluate Performance
y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)

print("=== Model Training Results ===")
print(f"Accuracy Score: {accuracy * 100:.2f}%\n")
print("Detailed Classification Report:\n")
print(classification_report(y_test, y_pred, target_names=label_encoder.classes_))